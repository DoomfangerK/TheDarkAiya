--Readme--

This Ukagaka, otherwise known as a ghost, was created for the Rowdy Hacks 2023 competition under the deadline of 24 hours.
There are four members of The D.A.R.K. Aiya, all from varying majors. Daniel, Alina, Russel, and Kathy.

Kathy: Mathematics, Freshman
Russel: Business, Freshman
Daniel: Communications, Freshman
Alina: Kinesiology. Freshman

Ed, Edd, and Eddy are a program that will run using SSP. They were coded in Yaya, otherwise known as Ayaya. Yaya is a Japanese coding language which is a distant varient of C.

In the small ammount of time we had to complete this project, we accomplished many things for the project and ourselves. Daniel, Alina, and Russel had never coded before. They were able to learn and understand Yaya enough to code entire strands of code.